package createData;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class createTable {
    public static void main(String[] args) throws IOException {
        BufferedWriter bw= new BufferedWriter(new FileWriter("/Users/hanhan.zhang/Desktop/Table/CreateTable1000.sql"));
        bw.write("create table Table_500 (");
        for (int i = 1; i <= 1000; i++) {
            bw.write("int_"+i+" int,");
        }
        bw.write(")");
        bw.flush();
        bw.close();
    }
}
