package createData;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class insertTable {
    public static void main(String[] args) throws IOException {
        BufferedWriter bw= new BufferedWriter(new FileWriter("/Users/hanhan.zhang/Desktop/Table/insertTable500.sql"));
        bw.write("insert into Table_500 values(");
        for (int i = 1; i <= 500; i++) {
            bw.write((int) (Math.random()*500+1)+",");
        }
        bw.write(")");
        bw.flush();
        bw.close();
    }




}
