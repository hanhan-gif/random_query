package createData;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class selectTable {
    public static void main(String[] args) throws IOException {
        BufferedWriter bw= new BufferedWriter(new FileWriter("/Users/hanhan.zhang/Desktop/Table/select501_cc.sql"));
        bw.write("select ");
        for (int i = 1; i <= 500; i++) {
//            bw.write("select int_"+i+",sum(int_"+i+"+1) from Table_500 group by int_"+i+";");
//            bw.write("select int_"+i+" from Table_500 group by int_"+i+";");
            bw.write("sum(int_"+i+"+1),");
//            bw.newLine();
        }
        bw.write(" from Table_500");
        bw.flush();
        bw.close();
    }





}
