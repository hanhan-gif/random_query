package io.kyligence.query;

import io.kyligence.tool.OlapQueryRandomizer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class writeSQL {
    public static void main(String[] args) throws IOException {
        BufferedWriter bw= new BufferedWriter(new FileWriter("/Users/hanhan.zhang/Desktop/table/select.txt"));
        for (int i = 1; i <= 2; i++) {
//            BufferedWriter bw = new BufferedWriter(new FileWriter("/Users/hanhan.zhang/Desktop/table/select_200.txt"));
            String sql = new OlapQueryRandomizer(
                    new File("/Users/hanhan.zhang/IdeaProjects/random_query/src/main/java/io/kyligence/tool/OlapQueryRandomizer.sample.json")).randomQuery();
            bw.write(sql + ";");
            bw.newLine();
//            bw.write("project,sql");
        }
//            bw.write(sql+";");
//            bw.newLine();
            bw.flush();
            bw.close();


    }
}
