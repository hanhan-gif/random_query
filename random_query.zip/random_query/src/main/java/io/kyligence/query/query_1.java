package io.kyligence.query;

import io.kyligence.tool.OlapQueryRandomizer;
import io.kyligence.tool.SendEmail;
import okhttp3.*;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import java.io.File;
import java.io.IOException;
import java.net.SocketTimeoutException;

public class query_1 {
    public static void main(String[] args) throws IOException, InterruptedException {
        int count = 0;
        int timeout_count = 0;
        while (true) {
            OkHttpClient client = new OkHttpClient().newBuilder()
                    .build();
            MediaType mediaType = MediaType.parse("application/json;charset=utf-8");
            String sql = new OlapQueryRandomizer(
                    new File("/Users/hanhan.zhang/IdeaProjects/random_query/src/main/java/io/kyligence/tool/OlapQueryRandomizer.sample.json")).randomQuery();
            RequestBody body = RequestBody.create(mediaType,
                    "{\"acceptPartial\":true,\"limit\":500,\"offset\":0,\"project\":\"test_homepage\",\"sql\":" + "\"" + sql + "\"" + ",\"backdoorToggles\":{\"DEBUG_TOGGLE_HTRACE_ENABLED\":false}}");
            Request request = new Request.Builder()
                    .url("http://10.1.2.166:7072/kylin/api/query")
                    .method("POST", body)
                    .addHeader("accept", "application/vnd.apache.kylin-v4+json")
                    .addHeader("authorization", "Basic QURNSU46S1lMSU4=")
                    .addHeader("content-type", "application/json;charset=utf-8")
                    .build();
            Response response = null;
            try {
               response = client.newCall(request).execute();
                if (response.code() == 200){
                    System.out.println(count += 1);
                }else {
                    SendEmail.sendEmail("zhh1505590@163.com", "出现异常");
                }
            } catch (SocketTimeoutException e){
                System.out.println("----------------timeout");
                System.out.println(sql);
                System.out.println(timeout_count+=1);
                System.out.println("-----------------");
            } catch (IOException e) {
                e.printStackTrace();
            } catch (AddressException e) {
                e.printStackTrace();
            } catch (MessagingException e) {
                e.printStackTrace();
            }
//            finally {
//                response.close();
//
//            }

        }
    }
}
