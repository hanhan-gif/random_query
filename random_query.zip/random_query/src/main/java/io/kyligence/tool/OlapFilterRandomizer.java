package io.kyligence.tool;

import java.util.ArrayList;
import java.util.Random;

public class OlapFilterRandomizer {

    public static class FilterConfig {
        public String raw;
        public String column;
        public String[] values;
    }
    
    private static class Node {
        Node n1, n2;
        String op;
        String v;
        
        public Node(String v) {
            this.v = v;
        }
        
        public Node(Node v1, String op, Node v2) {
            this.n1 = v1;
            this.op = op;
            this.n2 = v2;
        }
        
        public String toString() {
            StringBuilder buf = new StringBuilder();
            toString(false, 2, buf);
            return buf.toString();
        }
        
        public void toString(boolean brace, int indent, StringBuilder buf) {
            
            if (v != null) {
                indent(indent, buf);
                buf.append(v).append(" ");
                return;
            }
            
            if (brace) {
                indent(indent, buf);
                buf.append("(").append(" ");
            }
            
            if (n1 != null)
                n1.toString(true, indent + 2, buf);
            
            indent(indent + 2, buf);
            if (op != null)
                buf.append(op).append(" ");
            if (n2 != null)
                n2.toString(true, indent + 2, buf);
            
            if (brace) {
                indent(indent, buf);
                buf.append(")").append(" ");
            }
        }

        private void indent(int indent, StringBuilder buf) {
            for (int i = 0; i < indent; i++)
                buf.append(" ");
        }
    }

    // ============================================================================

    final private Random rand = new Random();
    final private FilterConfig[] candidates;

    public OlapFilterRandomizer(FilterConfig[] candidates) {
        this.candidates = candidates;
    }

    public String randomFilter(int nFilter) {
        ArrayList<String> conds = new ArrayList<>();
        for (int i = 0; i < nFilter; i++) {
            conds.add(randomCondition(candidates[rand.nextInt(candidates.length)]));
        }
        return joinUp(conds);
    }

    private String randomCondition(FilterConfig conf) {
        // =, <>, <, >, <=, >=, revert order
        // in, not in
        // between, not between
        // is null, is not null
        // like, not like
        // manipulate to non-existing value

        String[] ops = new String[] { //
                "=", "<>", "<", ">", "<=", ">=", //
                "in", "not in", //
                "between", "not between", //
                "is null", "is not null", //
                "like", "not like" //
        };
        String op = ops[rand.nextInt(ops.length)];

        if (op.contains("=") || op.contains("<") || op.contains(">")) {
            String v = randomValue(conf.values);
            if (rand.nextBoolean())
                return conf.column + op + v;
            else
                return v + op + conf.column;

        } else if (op.contains("in")) {
            StringBuilder buf = new StringBuilder();
            buf.append(conf.column + " " + op + " ");
            buf.append("(");
            int n = conf.values.length <= 1 ? 1 : rand.nextInt(conf.values.length - 1) + 1;
            for (int i = 0; i < n; i++) {
                if (i > 0)
                    buf.append(", ");
                buf.append(randomValue(conf.values));
            }
            buf.append(")");
            return buf.toString();

        } else if (op.contains("between")) {
            String v1 = randomValue(conf.values);
            String v2 = randomValue(conf.values);
            return conf.column + " " + op + " " + v1 + " and " + v2;

        } else if (op.contains("null")) {
            return conf.column + " " + op;

        } else if (op.contains("like")) {
            String v = randomValue(conf.values, 0.95);
            // work only with string value, exclude date like '2009-01-01'
            if (v.startsWith("'") && v.endsWith("'") && !isDateConst(v)) {
                return conf.column + " " + op + " " + v;
            } else
                return randomCondition(conf); // try our luck again
        }

        throw new RuntimeException("impossible");
    }

    private String randomValue(String[] values) {
        return randomValue(values, 0.05);
    }

    private String randomValue(String[] values, double saltChance) {
        String v = values[rand.nextInt(values.length)];

        // take chance to add some salt
        if (rand.nextDouble() < saltChance) {
            if (v.startsWith("'") && v.endsWith("'")) {
                if (isDateConst(v))
                    v = addSaltInDate(v);
                else
                    v = addSaltInString(v);
            } else {
                v = addSaltInNumber(v);
            }
        }

        return v;
    }

    private boolean isDateConst(String v) {
        // like '2009-01-01'
        return v.length() >= 12 && v.startsWith("'") && v.endsWith("'") //
                && v.charAt(5) == '-' && v.charAt(8) == '-';
    }

    private String addSaltInDate(String v) {
        // change the last digit of year
        return replaceCharAt(v, 4, rand.nextInt(10) + "");
    }

    private String addSaltInString(String v) {
        // add a % at either begin or end
        v = v.substring(1, v.length() - 1);
        if (rand.nextBoolean())
            v = v + "%";
        else
            v = "%" + v;
        return "'" + v + "'";
    }

    private String addSaltInNumber(String v) {
        // replace some random digits
        for (int i = 0; i < 3; i++) {
            int p = rand.nextInt(v.length());
            char c = v.charAt(p);
            if (c >= '0' && c <= '9')
                v = replaceCharAt(v, p, rand.nextInt(10) + "");
        }
        return v;
    }

    private String replaceCharAt(String v, int i, String c) {
        return v.substring(0, i) + c + v.substring(i + 1);
    }

    private String joinUp(ArrayList<String> conds) {
        if (conds.isEmpty())
            return "1=1";
        
        ArrayList<Node> nodes = new ArrayList<>();
        for (String c : conds)
            nodes.add(new Node(c));
        
        String[] ops = new String[] { "and", "and", "or", "or", "and", "and", "or", "or", "not" };
        while (true) {
            String op = ops[rand.nextInt(ops.length)];
            if ("not".equals(op)) {
                Node c1 = nodes.remove(rand.nextInt(nodes.size()));
                nodes.add(new Node(null, "not", c1));
            } else {
                if (nodes.size() == 1)
                    break;
                Node c1 = nodes.remove(rand.nextInt(nodes.size()));
                Node c2 = nodes.remove(rand.nextInt(nodes.size()));
                nodes.add(new Node(c1, op, c2));
            }
        }
        return nodes.get(0).toString();
    }

}
