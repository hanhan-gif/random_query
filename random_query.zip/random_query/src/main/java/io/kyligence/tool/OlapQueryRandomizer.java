package io.kyligence.tool;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.kyligence.tool.OlapFilterRandomizer.FilterConfig;

import java.io.*;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;

public class OlapQueryRandomizer {

    public static class Config {
        public String joinCore;
        public String[] extraJoinCandidates;
        public String[] groupByCandidates;
        public String[] measureCandidates;
        public FilterConfig[] filterCandidates;
    }

    public static void main(String[] args) throws IOException {
        io.kyligence.tool.OlapQueryRandomizer r = new io.kyligence.tool.OlapQueryRandomizer(
                new File("/Users/hanhan.zhang/IdeaProjects/random_query/src/main/java/io/kyligence/tool/OlapQueryRandomizer.sample.json"));
        System.out.println(r.randomQuery());
    }

    // ============================================================================

    final private Random rand = new Random();
    final private Config conf;

    public OlapQueryRandomizer(File conf) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        try (Reader rin = new InputStreamReader(new FileInputStream(conf), "UTF-8")) {
            this.conf = mapper.readValue(rin, Config.class);
        }
    }

    public OlapQueryRandomizer(Config conf) {
        this.conf = conf;
    }

    public String randomQuery() {
        return randomQuery( //
                conf.extraJoinCandidates.length == 0 ? 0 : rand.nextInt(conf.extraJoinCandidates.length), //
                rand.nextInt(conf.groupByCandidates.length - 1) + 1, //
                rand.nextInt(conf.measureCandidates.length), //
                rand.nextInt(conf.filterCandidates.length));
    }

    public String randomQuery(int nExtraJoin, int nDim, int nMea, int nFilter) {
        Set<String> dims = pick(nDim, conf.groupByCandidates);
        Set<String> meas = pick(nMea, conf.measureCandidates);
        String filter = new OlapFilterRandomizer(conf.filterCandidates).randomFilter(nFilter);
        Set<String> exJoins = pick(nExtraJoin, conf.extraJoinCandidates);

        StringBuilder buf = new StringBuilder();
        buf.append("select").append(" ");
        int i = 0;
        for (String s : dims) {
            buf.append("  ");
            if (i++ > 0)
                buf.append(",");
            buf.append(s).append(" ");
        }
        for (String s : meas) {
            buf.append("  ");
            buf.append(",");
            buf.append(s).append(" ");
        }
        buf.append("from").append(" ");
        buf.append("  ").append(conf.joinCore).append(" ");
        for (String s : exJoins) {
            buf.append("  ").append(s).append(" ");
        }
        buf.append("INNER JOIN SSB.PART ON LINEORDER.LO_PARTKEY=PART.P_PARTKEY INNER JOIN SSB.SUPPLIER  ON LINEORDER.LO_SUPPKEY=SUPPLIER.S_SUPPKEY INNER JOIN SSB.CUSTOMER ON LINEORDER.LO_CUSTKEY=CUSTOMER.C_CUSTKEY INNER JOIN SSB.DATES ON LINEORDER.LO_ORDERDATE=DATES.D_DATEKEY").append(" ");
        buf.append("where").append(" ");
        buf.append(filter).append(" ");
        buf.append("group by").append(" ");
        i = 0;
        for (String s : dims) {
            buf.append("  ");
            if (i++ > 0)
                buf.append(",");
            buf.append(s).append(" ");
        }
        if (rand.nextBoolean())
            buf.append("limit 500");
        return buf.toString();
    }

    private Set<String> pick(int p, String[] candi) {
        LinkedHashSet<String> ret = new LinkedHashSet<>();
        for (Integer i : pick(p, candi.length)) {
            ret.add(candi[i]);
        }
        return ret;
    }

    private Set<Integer> pick(int p, int total) {
        boolean[] bits = new boolean[total];
        LinkedHashSet<Integer> ret = new LinkedHashSet<>();
        for (int i = 0, j = -1; i < p; i++) {
            int step = rand.nextInt(total) + 1;
            while (step >= 0) {
                j++;
                if (j == total)
                    j = 0;

                if (bits[j] == false)
                    step--;
            }

            if (bits[j])
                throw new RuntimeException("impossible");

            bits[j] = true;
            ret.add(j);
        }

        if (ret.size() != p)
            throw new RuntimeException("impossible");
        return ret;
    }
}
