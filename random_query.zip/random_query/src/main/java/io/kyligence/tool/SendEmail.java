package io.kyligence.tool;

import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;

public class SendEmail {
    public static void sendEmail(String to ,String content) throws AddressException, MessagingException, IOException {
        // 1 创建一封邮件
        Properties props = new Properties(); // 用于连接邮件服务器的参数配置
        Session session = Session.getDefaultInstance(props); // 根据参数配置，创建会话对象
        MimeMessage message = new MimeMessage(session); // 创建邮件对象
        // 2 From 发件人
        message.setFrom(new InternetAddress("zhh1505590@163.com","hanhan","UTF-8"));
        // 3 TO 收件人
        message.setRecipient(MimeMessage.RecipientType.TO,new InternetAddress(to,"hanhan","UTF-8"));
        // 增加收件人
//        message.addRecipient(MimeMessage.RecipientType.TO,new InternetAddress("zhh1505590@163.com","hanhan","UTF-8"));
        // 抄送
//        message.addRecipient(MimeMessage.RecipientType.CC,new InternetAddress("zhh1505590@163.com","hanhan","UTF-8"));
        // 密送
//        message.addRecipient(MimeMessage.RecipientType.BCC,new InternetAddress("zhh1505590@163.com","hanhan","UTF-8"));

        // 4 Subject 邮件主题
        message.setSubject("持续查询","UTF-8");
        // 5 Content：邮件正文
        message.setContent(content,"text/html;charset=UTF-8");
        // 6 设置显示的发件时间
        message.setSentDate(new Date());
        // 7 保存前面的设置
        message.saveChanges();
        // 8 将邮件保存在本地
//        OutputStream out = new FileOutputStream("");
//        message.writeTo(out);
//        out.flush();
//        out.close();
    }
}
